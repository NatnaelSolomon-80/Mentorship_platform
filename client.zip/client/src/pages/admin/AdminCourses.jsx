import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import { apiGetCourses, apiApproveCourse, apiRejectCourse, apiDeleteCourse } from '../../api';
import toast from 'react-hot-toast';
import { BookOpen, Check, X, Trash2, Search } from 'lucide-react';

const AdminCourses = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [actioning, setActioning] = useState(null);

  useEffect(() => { load(); }, []);

  const load = async () => {
    try {
      const res = await apiGetCourses();
      setCourses(res.data.data || []);
    } catch { toast.error('Failed to load'); }
    finally { setLoading(false); }
  };

  const handleApprove = async (id) => {
    setActioning(id + 'approve');
    try {
      await apiApproveCourse(id);
      toast.success('Course approved!');
      await load();
    } catch { toast.error('Failed'); }
    finally { setActioning(null); }
  };

  const handleReject = async (id) => {
    setActioning(id + 'reject');
    try {
      await apiRejectCourse(id);
      toast.success('Course rejected');
      await load();
    } catch { toast.error('Failed'); }
    finally { setActioning(null); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this course permanently?')) return;
    try {
      await apiDeleteCourse(id);
      toast.success('Course deleted');
      await load();
    } catch { toast.error('Failed'); }
  };

  const filtered = courses.filter((c) => c.title.toLowerCase().includes(search.toLowerCase()));

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="Course Management" subtitle={`${courses.length} total courses`} />

      <div className="relative mb-6">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input className="input-field pl-9" placeholder="Search courses..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      <div className="space-y-3">
        {filtered.map((course) => (
          <div key={course._id} className="glass p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
              <BookOpen size={22} className="text-emerald-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <h3 className="font-bold text-white truncate">{course.title}</h3>
                <span className={`badge flex-shrink-0 ${course.isApproved ? 'badge-green' : 'badge-amber'}`}>
                  {course.isApproved ? 'Approved' : 'Pending'}
                </span>
              </div>
              <p className="text-xs text-slate-400">{course.mentorId?.name} • {course.category} • {course.level}</p>
              <p className="text-xs text-slate-500 mt-0.5">{course.modules?.length || 0} modules</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {!course.isApproved && (
                <button onClick={() => handleApprove(course._id)} disabled={!!actioning} className="btn-primary px-3 py-2 text-xs flex items-center gap-1">
                  <Check size={13} /> Approve
                </button>
              )}
              {course.isApproved && (
                <button onClick={() => handleReject(course._id)} disabled={!!actioning} className="btn-secondary px-3 py-2 text-xs flex items-center gap-1 border-amber-500/30 text-amber-400">
                  <X size={13} /> Revoke
                </button>
              )}
              <button onClick={() => handleDelete(course._id)} className="text-slate-500 hover:text-red-400 transition-colors p-2">
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="glass p-10 text-center">
            <BookOpen size={32} className="text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400 text-sm">No courses found</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default AdminCourses;
