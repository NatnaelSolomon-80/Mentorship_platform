import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import { apiGetUsers, apiApproveUser, apiToggleBlock, apiDeleteUser } from '../../api';
import toast from 'react-hot-toast';
import { Shield, Ban, Trash2, Check, Search, Filter } from 'lucide-react';

const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [actioning, setActioning] = useState(null);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    try {
      const res = await apiGetUsers();
      setUsers(res.data.data || []);
    } catch { toast.error('Failed to load users'); }
    finally { setLoading(false); }
  };

  const handleApprove = async (id) => {
    setActioning(id);
    try {
      await apiApproveUser(id);
      toast.success('User approved!');
      await load();
    } catch { toast.error('Failed'); }
    finally { setActioning(null); }
  };

  const handleToggleBlock = async (id) => {
    setActioning(id);
    try {
      await apiToggleBlock(id);
      toast.success('User updated!');
      await load();
    } catch { toast.error('Failed'); }
    finally { setActioning(null); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this user? This is irreversible!')) return;
    try {
      await apiDeleteUser(id);
      toast.success('User deleted');
      await load();
    } catch { toast.error('Failed'); }
  };

  const filtered = users.filter((u) => {
    const matchRole = filterRole === 'all' || u.role === filterRole;
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase());
    return matchRole && matchSearch;
  });

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="User Management" subtitle={`${users.length} total users on the platform`} />

      {/* Filters */}
      <div className="flex gap-3 mb-6 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="input-field pl-9" placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="input-field w-36" value={filterRole} onChange={(e) => setFilterRole(e.target.value)}>
          <option value="all">All Roles</option>
          <option value="student">Students</option>
          <option value="mentor">Mentors</option>
          <option value="employer">Employers</option>
        </select>
      </div>

      <div className="glass">
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>User</th>
                <th>Role</th>
                <th>Status</th>
                <th>Joined</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u._id}>
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="avatar text-sm">{u.name?.[0]}</div>
                      <div>
                        <p className="font-medium text-white">{u.name}</p>
                        <p className="text-xs text-slate-500">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`badge ${u.role === 'admin' ? 'badge-red' : u.role === 'mentor' ? 'badge-blue' : u.role === 'employer' ? 'badge-amber' : 'badge-green'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-1 flex-wrap">
                      {u.isBlocked ? <span className="badge badge-red">Blocked</span> : null}
                      {!u.isApproved ? <span className="badge badge-amber">Pending</span> : <span className="badge badge-green">Active</span>}
                    </div>
                  </td>
                  <td className="text-sm">{new Date(u.createdAt).toLocaleDateString()}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      {!u.isApproved && u.role !== 'student' && (
                        <button onClick={() => handleApprove(u._id)} disabled={actioning === u._id} className="btn-primary px-2 py-1.5 text-xs flex items-center gap-1">
                          <Check size={12} /> Approve
                        </button>
                      )}
                      {u.role !== 'admin' && (
                        <button onClick={() => handleToggleBlock(u._id)} disabled={actioning === u._id} className={`px-2 py-1.5 text-xs flex items-center gap-1 rounded-lg border font-semibold transition-colors ${u.isBlocked ? 'border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10' : 'border-amber-500/30 text-amber-400 hover:bg-amber-500/10'}`}>
                          <Ban size={12} /> {u.isBlocked ? 'Unblock' : 'Block'}
                        </button>
                      )}
                      {u.role !== 'admin' && (
                        <button onClick={() => handleDelete(u._id)} className="text-slate-500 hover:text-red-400 transition-colors p-1.5">
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default AdminUsers;
