import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import StatCard from '../../components/StatCard';
import PageHeader from '../../components/PageHeader';
import { apiGetUsers, apiGetCourses, apiGetReports } from '../../api';
import { Users, BookOpen, FileText, Shield, TrendingUp, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const [stats, setStats] = useState({ users: 0, mentors: 0, courses: 0, pendingCourses: 0, reports: 0, pendingReports: 0 });
  const [recentUsers, setRecentUsers] = useState([]);
  const [recentCourses, setRecentCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [uRes, cRes, rRes] = await Promise.all([
          apiGetUsers(),
          apiGetCourses(),
          apiGetReports(),
        ]);
        const users = uRes.data.data || [];
        const courses = cRes.data.data || [];
        const reports = rRes.data.data || [];
        setStats({
          users: users.length,
          mentors: users.filter((u) => u.role === 'mentor').length,
          courses: courses.length,
          pendingCourses: courses.filter((c) => !c.isApproved).length,
          reports: reports.length,
          pendingReports: reports.filter((r) => r.status === 'pending').length,
        });
        setRecentUsers(users.filter((u) => !u.isApproved && u.role !== 'student').slice(0, 5));
        setRecentCourses(courses.filter((c) => !c.isApproved).slice(0, 5));
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    fetchAll();
  }, []);

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="Admin Dashboard" subtitle="Platform overview and management" />

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <StatCard icon={Users} label="Total Users" value={stats.users} color="text-blue-400" />
        <StatCard icon={Shield} label="Mentors" value={stats.mentors} color="text-emerald-400" />
        <StatCard icon={BookOpen} label="Courses" value={stats.courses} color="text-purple-400" />
        <StatCard icon={Clock} label="Pending Courses" value={stats.pendingCourses} color="text-amber-400" />
        <StatCard icon={FileText} label="Reports" value={stats.reports} color="text-red-400" />
        <StatCard icon={TrendingUp} label="Open Reports" value={stats.pendingReports} color="text-orange-400" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Pending Approvals */}
        <div className="glass p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white">Pending User Approvals</h2>
            <Link to="/admin/users" className="text-sm text-emerald-400 hover:text-emerald-300">Manage →</Link>
          </div>
          {recentUsers.length === 0 ? (
            <p className="text-slate-400 text-sm text-center py-4">No pending approvals</p>
          ) : (
            <div className="space-y-3">
              {recentUsers.map((u) => (
                <div key={u._id} className="flex items-center gap-3 glass-sm p-3">
                  <div className="avatar text-sm">{u.name?.[0]}</div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white">{u.name}</p>
                    <p className="text-xs text-slate-400">{u.email}</p>
                  </div>
                  <span className={`badge ${u.role === 'mentor' ? 'badge-blue' : 'badge-purple'}`}>{u.role}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pending Course Approvals */}
        <div className="glass p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white">Pending Course Approvals</h2>
            <Link to="/admin/courses" className="text-sm text-emerald-400 hover:text-emerald-300">Manage →</Link>
          </div>
          {recentCourses.length === 0 ? (
            <p className="text-slate-400 text-sm text-center py-4">No pending courses</p>
          ) : (
            <div className="space-y-3">
              {recentCourses.map((c) => (
                <div key={c._id} className="flex items-center gap-3 glass-sm p-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                    <BookOpen size={14} className="text-emerald-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{c.title}</p>
                    <p className="text-xs text-slate-400">{c.mentorId?.name}</p>
                  </div>
                  <span className="badge badge-amber">Pending</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default AdminDashboard;
