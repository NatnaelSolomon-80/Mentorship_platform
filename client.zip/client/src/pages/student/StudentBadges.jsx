import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import { apiGetMyBadges } from '../../api';

const StudentBadges = () => {
  const [badges, setBadges] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGetMyBadges()
      .then((res) => setBadges(res.data.data || []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="My Badges" subtitle="Achievements earned through your learning journey" />

      {badges.length === 0 ? (
        <div className="glass p-12 text-center">
          <div className="text-5xl mb-4">🏅</div>
          <h3 className="font-bold text-white mb-2">No badges yet</h3>
          <p className="text-slate-400 text-sm">Complete courses to earn badges!</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {badges.map((ub) => (
            <div key={ub._id} className="glass p-6 text-center hover:border-amber-500/30 transition-all">
              <div className="text-5xl mb-3" style={{ filter: 'drop-shadow(0 0 8px rgba(245,158,11,0.4))' }}>
                {ub.badgeId?.icon || '🏅'}
              </div>
              <h3 className="font-bold text-white text-sm mb-1">{ub.badgeId?.title}</h3>
              <p className="text-xs text-slate-400 mb-2">{ub.badgeId?.description}</p>
              {ub.courseId && <p className="text-xs text-emerald-400 mt-1">{ub.courseId.title}</p>}
              <p className="text-xs text-slate-600 mt-1">{new Date(ub.earnedAt).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
};

export default StudentBadges;
