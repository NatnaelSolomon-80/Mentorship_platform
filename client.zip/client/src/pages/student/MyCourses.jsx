import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import { apiGetEnrolledCourses, apiGetProgress } from '../../api';
import { BookOpen, Lock, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const MyCourses = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGetEnrolledCourses()
      .then((res) => setCourses(res.data.data || []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="My Courses" subtitle="Continue your learning journey" />

      {courses.length === 0 ? (
        <EmptyState
          icon={Lock}
          title="No enrolled courses"
          description="You must request and get accepted by a mentor before accessing course content."
          action={<Link to="/student/browse" className="btn-primary">Browse Courses</Link>}
        />
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {courses.map((course) => (
            <Link
              key={course._id}
              to={`/student/course/${course._id}`}
              className="glass overflow-hidden hover:border-emerald-500/30 transition-all block"
            >
              <div className="h-32 bg-gradient-to-br from-emerald-900/40 to-slate-800 flex items-center justify-center">
                {course.thumbnail ? (
                  <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
                ) : (
                  <BookOpen size={32} className="text-emerald-400/40" />
                )}
              </div>
              <div className="p-5">
                <p className="text-xs text-slate-500 mb-1">{course.category}</p>
                <h3 className="font-bold text-white mb-1">{course.title}</h3>
                <p className="text-xs text-slate-400 mb-3">{course.mentorId?.name}</p>
                <div className="progress-bar mb-1">
                  <div className="progress-fill" style={{ width: '0%' }} />
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-xs text-slate-500">In progress</p>
                  <ChevronRight size={14} className="text-emerald-400" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
};

export default MyCourses;
