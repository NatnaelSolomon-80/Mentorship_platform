import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import Modal from '../../components/Modal';
import { apiGetCourses, apiGetMentors, apiRequestEnrollment, apiGetEnrollmentRequests, apiCheckEnrollment } from '../../api';
import toast from 'react-hot-toast';
import { BookOpen, Search, Users, Lock, ChevronRight, Filter } from 'lucide-react';

const BrowseCourses = () => {
  const [courses, setCourses] = useState([]);
  const [mentors, setMentors] = useState([]);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [selectedMentor, setSelectedMentor] = useState('');
  const [requestMsg, setRequestMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [cRes, mRes, rRes] = await Promise.all([
          apiGetCourses(),
          apiGetMentors(),
          apiGetEnrollmentRequests(),
        ]);
        setCourses(cRes.data.data || []);
        setMentors(mRes.data.data || []);
        setRequests(rRes.data.data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  const getRequestStatus = (courseId) => requests.find((r) => r.courseId?._id === courseId);

  const handleRequest = async (e) => {
    e.preventDefault();
    if (!selectedMentor) return toast.error('Please select a mentor');
    setSubmitting(true);
    try {
      await apiRequestEnrollment({ courseId: selectedCourse._id, mentorId: selectedMentor, message: requestMsg });
      toast.success('Enrollment request sent! Waiting for mentor approval.');
      const rRes = await apiGetEnrollmentRequests();
      setRequests(rRes.data.data || []);
      setSelectedCourse(null);
      setSelectedMentor('');
      setRequestMsg('');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Request failed');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = courses.filter((c) => c.title.toLowerCase().includes(search.toLowerCase()));
  const courseMentors = selectedCourse ? mentors.filter((m) => m._id === selectedCourse.mentorId?._id || true) : [];

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="Browse Courses" subtitle="Find courses and request a mentor to begin your journey" />

      {/* Search */}
      <div className="relative mb-6">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          className="input-field pl-9"
          placeholder="Search courses..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={BookOpen} title="No courses found" description="No approved courses available yet. Check back later." />
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((course) => {
            const req = getRequestStatus(course._id);
            return (
              <div key={course._id} className="glass overflow-hidden hover:border-emerald-500/30 transition-all">
                {/* Thumbnail */}
                <div className="h-36 bg-gradient-to-br from-emerald-900/40 to-slate-800 flex items-center justify-center relative">
                  {course.thumbnail ? (
                    <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
                  ) : (
                    <BookOpen size={36} className="text-emerald-400/40" />
                  )}
                  <div className="absolute top-3 right-3">
                    <span className={`badge ${course.level === 'Beginner' ? 'badge-green' : course.level === 'Advanced' ? 'badge-red' : 'badge-amber'}`}>
                      {course.level}
                    </span>
                  </div>
                </div>

                <div className="p-5">
                  <p className="text-xs text-slate-500 mb-1">{course.category}</p>
                  <h3 className="font-bold text-white mb-1 leading-snug">{course.title}</h3>
                  <p className="text-sm text-slate-400 line-clamp-2 mb-3">{course.description}</p>

                  {course.mentorId && (
                    <div className="flex items-center gap-2 mb-4">
                      <div className="avatar w-6 h-6 text-xs">{course.mentorId.name?.[0]}</div>
                      <span className="text-xs text-slate-400">{course.mentorId.name}</span>
                    </div>
                  )}

                  {req ? (
                    <div className={`badge w-full justify-center py-2 ${req.status === 'pending' ? 'badge-amber' : req.status === 'accepted' ? 'badge-green' : 'badge-red'}`}>
                      {req.status === 'pending' ? '⏳ Request Pending' : req.status === 'accepted' ? '✅ Enrolled' : '❌ Rejected'}
                    </div>
                  ) : (
                    <button
                      onClick={() => setSelectedCourse(course)}
                      className="btn-primary w-full flex items-center justify-center gap-2"
                    >
                      <Users size={15} /> Request Mentor
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Enrollment Request Modal */}
      {selectedCourse && (
        <Modal title="Request Enrollment" onClose={() => setSelectedCourse(null)}>
          <div className="mb-4 p-3 rounded-lg bg-slate-800/50 border border-white/5">
            <p className="font-semibold text-white text-sm">{selectedCourse.title}</p>
            <p className="text-xs text-slate-400 mt-0.5">{selectedCourse.category} • {selectedCourse.level}</p>
          </div>

          <form onSubmit={handleRequest} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Select Mentor</label>
              <select
                className="input-field"
                value={selectedMentor}
                onChange={(e) => setSelectedMentor(e.target.value)}
                required
              >
                <option value="">-- Choose a mentor --</option>
                {/* Use the course's mentor as the primary option */}
                {selectedCourse.mentorId && (
                  <option value={selectedCourse.mentorId._id}>{selectedCourse.mentorId.name}</option>
                )}
                {mentors.filter(m => m._id !== selectedCourse.mentorId?._id).map((m) => (
                  <option key={m._id} value={m._id}>{m.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Message (optional)</label>
              <textarea
                className="input-field resize-none"
                rows={3}
                placeholder="Tell the mentor why you want to take this course..."
                value={requestMsg}
                onChange={(e) => setRequestMsg(e.target.value)}
              />
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => setSelectedCourse(null)} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" className="btn-primary flex-1" disabled={submitting}>
                {submitting ? 'Sending...' : 'Send Request'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  );
};

export default BrowseCourses;
