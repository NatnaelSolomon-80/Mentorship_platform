import { useEffect, useState, useRef } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import { apiGetContacts, apiGetConversation, apiSendMessage, apiGetMentorStudents } from '../../api';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';
import { Send, MessageCircle } from 'lucide-react';

const Chat = () => {
  const { user } = useAuth();
  const [contacts, setContacts] = useState([]);
  const [activeContact, setActiveContact] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    const loadContacts = async () => {
      try {
        // For mentors, get their students too
        const [contactsRes] = await Promise.all([apiGetContacts()]);
        setContacts(contactsRes.data.data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    loadContacts();
  }, []);

  useEffect(() => {
    if (activeContact) loadMessages();
  }, [activeContact]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadMessages = async () => {
    try {
      const res = await apiGetConversation(activeContact.user._id);
      setMessages(res.data.data || []);
    } catch { toast.error('Failed to load messages'); }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setSending(true);
    try {
      const res = await apiSendMessage({ receiverId: activeContact.user._id, text });
      setMessages((prev) => [...prev, res.data.data]);
      setText('');
    } catch { toast.error('Failed to send'); }
    finally { setSending(false); }
  };

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="Messages" subtitle="Chat with your mentors and students" />

      <div className="glass flex" style={{ height: '65vh' }}>
        {/* Contacts panel */}
        <div className="w-72 border-r border-white/5 flex flex-col">
          <div className="p-4 border-b border-white/5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Conversations</p>
          </div>
          <div className="flex-1 overflow-y-auto">
            {contacts.length === 0 ? (
              <div className="p-6 text-center">
                <MessageCircle size={28} className="text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-500">No conversations yet</p>
              </div>
            ) : (
              contacts.map(({ user: contact, lastMessage }) => (
                <button
                  key={contact._id}
                  onClick={() => setActiveContact({ user: contact })}
                  className={`w-full p-4 flex items-center gap-3 hover:bg-slate-700/30 transition-all text-left ${activeContact?.user._id === contact._id ? 'bg-emerald-500/10 border-l-2 border-emerald-500' : ''}`}
                >
                  <div className="avatar text-sm">{contact.name?.[0]}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{contact.name}</p>
                    <p className="text-xs text-slate-500 truncate">{lastMessage?.text}</p>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Messages panel */}
        {activeContact ? (
          <div className="flex-1 flex flex-col">
            {/* Header */}
            <div className="p-4 border-b border-white/5 flex items-center gap-3">
              <div className="avatar text-sm">{activeContact.user.name?.[0]}</div>
              <div>
                <p className="font-semibold text-white text-sm">{activeContact.user.name}</p>
                <p className="text-xs text-slate-500 capitalize">{activeContact.user.role}</p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((msg) => {
                const isMine = msg.senderId?._id === user._id || msg.senderId === user._id;
                return (
                  <div key={msg._id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                    <div className={isMine ? 'chat-bubble-sent' : 'chat-bubble-recv'}>
                      <p>{msg.text}</p>
                      <p className={`text-xs mt-1 ${isMine ? 'text-green-200' : 'text-slate-500'}`}>
                        {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSend} className="p-4 border-t border-white/5 flex gap-3">
              <input
                className="input-field flex-1"
                placeholder="Type a message..."
                value={text}
                onChange={(e) => setText(e.target.value)}
              />
              <button type="submit" className="btn-primary px-4" disabled={sending}>
                <Send size={16} />
              </button>
            </form>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageCircle size={40} className="text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">Select a conversation to start chatting</p>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default Chat;
