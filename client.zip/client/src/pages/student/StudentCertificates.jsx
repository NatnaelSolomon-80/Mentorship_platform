import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import EmptyState from '../../components/EmptyState';
import { apiGetMyCertificates, apiGetCertRequests } from '../../api';
import { Award, ExternalLink, Clock, CheckCircle, XCircle } from 'lucide-react';

const StudentCertificates = () => {
  const [certs, setCerts] = useState([]);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([apiGetMyCertificates(), apiGetCertRequests()])
      .then(([cRes, rRes]) => {
        setCerts(cRes.data.data || []);
        setRequests(rRes.data.data || []);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="My Certificates" subtitle="Your earned certificates and pending requests" />

      {/* Issued Certificates */}
      <div className="mb-6">
        <h2 className="text-lg font-bold text-white mb-4">Issued Certificates ({certs.length})</h2>
        {certs.length === 0 ? (
          <div className="glass p-8 text-center">
            <div className="text-4xl mb-3">🏆</div>
            <p className="text-slate-400 text-sm">No certificates yet. Complete a course to earn one!</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {certs.map((cert) => (
              <div key={cert._id} className="glass p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-emerald-500/20 flex items-center justify-center flex-shrink-0">
                    <Award size={24} className="text-amber-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-white mb-1">{cert.courseId?.title}</h3>
                    <p className="text-xs text-slate-400">Mentor: {cert.mentorId?.name}</p>
                    <p className="text-xs text-slate-500 mt-1">Issued: {new Date(cert.issuedAt).toLocaleDateString()}</p>
                  </div>
                </div>
                <a
                  href={`/api/certificates/${cert._id}/view`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-amber w-full mt-4 flex items-center justify-center gap-2 text-sm"
                >
                  <ExternalLink size={15} /> View Certificate
                </a>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Pending Requests */}
      {requests.length > 0 && (
        <div>
          <h2 className="text-lg font-bold text-white mb-4">Certificate Requests</h2>
          <div className="space-y-3">
            {requests.map((req) => (
              <div key={req._id} className="glass-sm p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-white text-sm">{req.courseId?.title}</p>
                  <p className="text-xs text-slate-400">Mentor: {req.mentorId?.name}</p>
                </div>
                <span className={`badge ${req.status === 'pending' ? 'badge-amber' : req.status === 'approved' ? 'badge-green' : 'badge-red'}`}>
                  {req.status === 'pending' && <><Clock size={12} /> Pending</>}
                  {req.status === 'approved' && <><CheckCircle size={12} /> Approved</>}
                  {req.status === 'rejected' && <><XCircle size={12} /> Rejected</>}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </DashboardLayout>
  );
};

export default StudentCertificates;
