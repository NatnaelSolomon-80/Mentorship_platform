import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import StatCard from '../../components/StatCard';
import PageHeader from '../../components/PageHeader';
import { useAuth } from '../../context/AuthContext';
import { apiGetEnrolledCourses, apiGetEnrollmentRequests, apiGetMyBadges, apiGetMyCertificates } from '../../api';
import { BookOpen, Award, Star, Clock, TrendingUp, Users } from 'lucide-react';
import { Link } from 'react-router-dom';

const StudentDashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({ courses: 0, certificates: 0, badges: 0, pending: 0 });
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [coursesRes, certsRes, badgesRes, reqsRes] = await Promise.all([
          apiGetEnrolledCourses(),
          apiGetMyCertificates(),
          apiGetMyBadges(),
          apiGetEnrollmentRequests(),
        ]);
        setEnrolledCourses(coursesRes.data.data || []);
        setStats({
          courses: coursesRes.data.data?.length || 0,
          certificates: certsRes.data.data?.length || 0,
          badges: badgesRes.data.data?.length || 0,
          pending: reqsRes.data.data?.filter((r) => r.status === 'pending').length || 0,
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader
        title={`Welcome back, ${user?.name?.split(' ')[0]}! 👋`}
        subtitle="Track your learning progress and achievements"
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard icon={BookOpen} label="Enrolled Courses" value={stats.courses} color="text-emerald-400" />
        <StatCard icon={Award} label="Certificates" value={stats.certificates} color="text-amber-400" />
        <StatCard icon={Star} label="Badges Earned" value={stats.badges} color="text-blue-400" />
        <StatCard icon={Clock} label="Pending Requests" value={stats.pending} color="text-purple-400" />
      </div>

      {/* My Courses */}
      <div className="glass p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-white">My Active Courses</h2>
          <Link to="/student/courses" className="text-sm text-emerald-400 hover:text-emerald-300">View All →</Link>
        </div>
        {enrolledCourses.length === 0 ? (
          <div className="text-center py-10">
            <div className="text-4xl mb-3">📚</div>
            <p className="text-slate-400 text-sm mb-4">You haven't enrolled in any courses yet.</p>
            <Link to="/student/browse" className="btn-primary inline-flex items-center gap-2">
              <BookOpen size={16} /> Browse Courses
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {enrolledCourses.slice(0, 6).map((course) => (
              <Link key={course._id} to={`/student/course/${course._id}`} className="glass-sm p-4 hover:border-emerald-500/30 transition-all block">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500/20 to-amber-500/20 flex items-center justify-center flex-shrink-0">
                    <BookOpen size={18} className="text-emerald-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-white text-sm truncate">{course.title}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">{course.mentorId?.name}</p>
                    <div className="mt-2">
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: '0%' }} />
                      </div>
                      <p className="text-xs text-slate-500 mt-1">0% complete</p>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-4">
        <Link to="/student/browse" className="glass p-5 hover:border-emerald-500/30 transition-all cursor-pointer block text-center">
          <div className="text-3xl mb-2">🔍</div>
          <p className="font-semibold text-white text-sm">Browse Courses</p>
          <p className="text-xs text-slate-400 mt-1">Find your next course</p>
        </Link>
        <Link to="/student/chat" className="glass p-5 hover:border-blue-500/30 transition-all cursor-pointer block text-center">
          <div className="text-3xl mb-2">💬</div>
          <p className="font-semibold text-white text-sm">Chat with Mentor</p>
          <p className="text-xs text-slate-400 mt-1">Get guidance & support</p>
        </Link>
        <Link to="/student/certificates" className="glass p-5 hover:border-amber-500/30 transition-all cursor-pointer block text-center">
          <div className="text-3xl mb-2">🏆</div>
          <p className="font-semibold text-white text-sm">My Certificates</p>
          <p className="text-xs text-slate-400 mt-1">View your achievements</p>
        </Link>
      </div>
    </DashboardLayout>
  );
};

export default StudentDashboard;
