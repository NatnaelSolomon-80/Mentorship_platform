import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import DashboardLayout from '../../components/DashboardLayout';
import Modal from '../../components/Modal';
import { apiGetCourse, apiGetModules, apiGetProgress, apiMarkLesson, apiMarkModule, apiGetTests, apiSubmitTest, apiGetResults, apiRequestCertificate, apiGetCertRequests, apiCreateReport } from '../../api';
import toast from 'react-hot-toast';
import { CheckCircle, Circle, Play, FileText, BookOpen, ChevronDown, ChevronRight, Lock, Award, Flag, ExternalLink } from 'lucide-react';

const lessonTypeIcon = { video: Play, note: FileText, pdf: FileText };
const lessonTypeColor = { video: 'text-blue-400', note: 'text-emerald-400', pdf: 'text-amber-400' };

const CourseLearning = () => {
  const { courseId } = useParams();
  const [course, setCourse] = useState(null);
  const [modules, setModules] = useState([]);
  const [progress, setProgress] = useState(null);
  const [expandedModule, setExpandedModule] = useState(null);
  const [activeLesson, setActiveLesson] = useState(null);
  const [tests, setTests] = useState([]);
  const [results, setResults] = useState([]);
  const [certRequest, setCertRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCertModal, setShowCertModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportMsg, setReportMsg] = useState('');
  const [activeTest, setActiveTest] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submittingTest, setSubmittingTest] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [cRes, mRes, pRes, tRes, rRes, crRes] = await Promise.all([
          apiGetCourse(courseId),
          apiGetModules(courseId),
          apiGetProgress(courseId),
          apiGetTests(courseId),
          apiGetResults(courseId),
          apiGetCertRequests(),
        ]);
        setCourse(cRes.data.data);
        setModules(mRes.data.data || []);
        setProgress(pRes.data.data);
        setTests(tRes.data.data || []);
        setResults(rRes.data.data || []);
        const myCertReq = crRes.data.data?.find((r) => r.courseId?._id === courseId);
        setCertRequest(myCertReq);
        if (mRes.data.data?.length > 0) setExpandedModule(mRes.data.data[0]._id);
      } catch (err) {
        toast.error('Failed to load course content');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [courseId]);

  const isLessonDone = (lessonId) => progress?.completedLessons?.some((l) => l === lessonId || l._id === lessonId);
  const isModuleDone = (moduleId) => progress?.completedModules?.some((m) => m === moduleId || m._id === moduleId);
  const completedModulesCount = modules.filter((m) => isModuleDone(m._id)).length;
  const totalModules = modules.length;
  const progressPct = totalModules > 0 ? Math.round((completedModulesCount / totalModules) * 100) : 0;
  const finalTest = tests.find((t) => t.type === 'final');
  const finalTestPassed = results.some((r) => r.testId?._id === finalTest?._id && r.passed);
  const canRequestCert = progressPct === 100 && (!finalTest || finalTestPassed);

  const handleMarkLesson = async (lessonId) => {
    try {
      const res = await apiMarkLesson(courseId, lessonId);
      setProgress(res.data.data);
      toast.success('Lesson marked complete ✅');
    } catch { toast.error('Failed to mark lesson'); }
  };

  const handleMarkModule = async (moduleId) => {
    try {
      const res = await apiMarkModule(courseId, moduleId);
      setProgress(res.data.data);
      toast.success('Module completed! 🎉');
    } catch { toast.error('Failed to mark module'); }
  };

  const handleSubmitTest = async (e) => {
    e.preventDefault();
    if (Object.keys(answers).length < activeTest.questions.length) return toast.error('Answer all questions');
    setSubmittingTest(true);
    try {
      const res = await apiSubmitTest(activeTest._id, {
        answers: activeTest.questions.map((_, i) => parseInt(answers[i])),
        courseId,
      });
      setTestResult(res.data.data);
      const rRes = await apiGetResults(courseId);
      setResults(rRes.data.data || []);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit');
    } finally {
      setSubmittingTest(false);
    }
  };

  const handleCertRequest = async () => {
    try {
      await apiRequestCertificate({ courseId, mentorId: course.mentorId._id });
      toast.success('Certificate request sent to your mentor!');
      setShowCertModal(false);
      const crRes = await apiGetCertRequests();
      setCertRequest(crRes.data.data?.find((r) => r.courseId?._id === courseId));
    } catch (err) {
      toast.error(err.response?.data?.message || 'Request failed');
    }
  };

  const handleReport = async (e) => {
    e.preventDefault();
    try {
      await apiCreateReport({ courseId, contentId: activeLesson?._id || course._id, contentType: activeLesson ? 'lesson' : 'course', message: reportMsg });
      toast.success('Report submitted. Admin will review it.');
      setShowReportModal(false);
      setReportMsg('');
    } catch { toast.error('Failed to submit report'); }
  };

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;
  if (!course) return <DashboardLayout><p className="text-slate-400">Course not found.</p></DashboardLayout>;

  return (
    <DashboardLayout>
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Course Header */}
          <div className="glass p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="badge badge-green mb-2">{course.category}</span>
                <h1 className="text-2xl font-bold text-white mb-2">{course.title}</h1>
                <p className="text-slate-400 text-sm">{course.description}</p>
                <div className="flex items-center gap-2 mt-3">
                  <div className="avatar w-7 h-7 text-xs">{course.mentorId?.name?.[0]}</div>
                  <span className="text-sm text-slate-300">{course.mentorId?.name}</span>
                </div>
              </div>
              <button onClick={() => setShowReportModal(true)} className="text-slate-500 hover:text-red-400 transition-colors flex-shrink-0" title="Report content">
                <Flag size={18} />
              </button>
            </div>

            {/* Overall Progress */}
            <div className="mt-4 p-3 rounded-lg bg-slate-800/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-300">Overall Progress</span>
                <span className="text-sm font-bold text-emerald-400">{progressPct}%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${progressPct}%` }} />
              </div>
              <p className="text-xs text-slate-500 mt-1">{completedModulesCount}/{totalModules} modules completed</p>
            </div>
          </div>

          {/* Lesson Viewer */}
          {activeLesson && (
            <div className="glass p-6">
              <h2 className="font-bold text-white mb-4 flex items-center gap-2">
                {activeLesson.type === 'video' ? <Play size={18} className="text-blue-400" /> : <FileText size={18} className="text-emerald-400" />}
                {activeLesson.title}
              </h2>
              {activeLesson.type === 'video' ? (
                <div className="aspect-video rounded-lg overflow-hidden bg-black">
                  <iframe
                    src={activeLesson.contentUrl.replace('watch?v=', 'embed/')}
                    className="w-full h-full"
                    allowFullScreen
                    title={activeLesson.title}
                  />
                </div>
              ) : (
                <div className="p-4 rounded-lg bg-slate-800/50 border border-white/5">
                  <a href={activeLesson.contentUrl} target="_blank" rel="noopener noreferrer" className="btn-primary inline-flex items-center gap-2">
                    <ExternalLink size={16} />
                    {activeLesson.type === 'pdf' ? 'Open PDF' : 'View Note'}
                  </a>
                </div>
              )}
              {!isLessonDone(activeLesson._id) && (
                <button onClick={() => handleMarkLesson(activeLesson._id)} className="btn-primary mt-4 flex items-center gap-2">
                  <CheckCircle size={16} /> Mark as Complete
                </button>
              )}
              {isLessonDone(activeLesson._id) && (
                <span className="badge badge-green mt-4">✅ Completed</span>
              )}
            </div>
          )}

          {/* Test Section */}
          {activeTest && (
            <div className="glass p-6">
              <h2 className="font-bold text-white mb-4">📝 {activeTest.title}</h2>
              {testResult ? (
                <div className={`p-4 rounded-lg border ${testResult.passed ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                  <p className="text-lg font-bold text-white">{testResult.passed ? '🎉 Passed!' : '😔 Not Passed'}</p>
                  <p className="text-slate-300">Score: <strong>{testResult.score}%</strong></p>
                  <p className="text-slate-400 text-sm">{testResult.correct}/{testResult.total} correct</p>
                  <button onClick={() => { setActiveTest(null); setTestResult(null); setAnswers({}); }} className="btn-secondary mt-3">Close Test</button>
                </div>
              ) : (
                <form onSubmit={handleSubmitTest} className="space-y-4">
                  {activeTest.questions.map((q, i) => (
                    <div key={i} className="p-4 rounded-lg bg-slate-800/50 border border-white/5">
                      <p className="text-sm font-semibold text-white mb-3">{i + 1}. {q.questionText}</p>
                      <div className="space-y-2">
                        {q.options.map((opt, j) => (
                          <label key={j} className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-all ${answers[i] == j ? 'bg-emerald-500/10 border border-emerald-500/30' : 'hover:bg-slate-700/50 border border-transparent'}`}>
                            <input type="radio" name={`q${i}`} value={j} onChange={() => setAnswers({ ...answers, [i]: j })} className="accent-emerald-500" />
                            <span className="text-sm text-slate-300">{opt}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  ))}
                  <button type="submit" className="btn-primary" disabled={submittingTest}>
                    {submittingTest ? 'Submitting...' : 'Submit Answers'}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Sidebar - Modules List */}
        <div className="space-y-4">
          {/* Certificate Button */}
          <div className="glass p-4">
            {canRequestCert ? (
              <div>
                {certRequest ? (
                  <div className={`badge w-full justify-center py-3 ${certRequest.status === 'pending' ? 'badge-amber' : certRequest.status === 'approved' ? 'badge-green' : 'badge-red'}`}>
                    {certRequest.status === 'pending' ? '⏳ Certificate Pending' : certRequest.status === 'approved' ? '🏆 Certificate Approved' : '❌ Certificate Rejected'}
                  </div>
                ) : (
                  <button onClick={() => setShowCertModal(true)} className="btn-amber w-full flex items-center justify-center gap-2">
                    <Award size={16} /> Request Certificate
                  </button>
                )}
              </div>
            ) : (
              <div className="text-center">
                <Lock size={20} className="text-slate-500 mx-auto mb-2" />
                <p className="text-xs text-slate-500">Complete all modules{finalTest ? ' and pass the final test' : ''} to unlock certificate</p>
              </div>
            )}
          </div>

          {/* Modules */}
          <div className="glass p-4">
            <h3 className="font-bold text-white mb-3 text-sm">Course Content</h3>
            <div className="space-y-2">
              {modules.map((mod) => {
                const modTest = tests.find((t) => t.moduleId === mod._id);
                return (
                  <div key={mod._id} className="rounded-lg overflow-hidden border border-white/5">
                    <button
                      onClick={() => setExpandedModule(expandedModule === mod._id ? null : mod._id)}
                      className="w-full flex items-center gap-2 p-3 bg-slate-800/50 hover:bg-slate-700/50 transition-all text-left"
                    >
                      {isModuleDone(mod._id) ? <CheckCircle size={16} className="text-emerald-400 flex-shrink-0" /> : <Circle size={16} className="text-slate-500 flex-shrink-0" />}
                      <span className="text-sm font-medium text-white flex-1">{mod.title}</span>
                      {expandedModule === mod._id ? <ChevronDown size={14} className="text-slate-400" /> : <ChevronRight size={14} className="text-slate-400" />}
                    </button>

                    {expandedModule === mod._id && (
                      <div className="bg-slate-900/30 divide-y divide-white/5">
                        {(mod.lessons || []).map((lesson) => {
                          const Icon = lessonTypeIcon[lesson.type] || FileText;
                          return (
                            <button
                              key={lesson._id}
                              onClick={() => { setActiveLesson(lesson); setActiveTest(null); }}
                              className={`w-full flex items-center gap-2 p-2.5 text-left hover:bg-slate-700/30 transition-all ${activeLesson?._id === lesson._id ? 'bg-emerald-500/10' : ''}`}
                            >
                              {isLessonDone(lesson._id) ? <CheckCircle size={14} className="text-emerald-400 flex-shrink-0" /> : <Icon size={14} className={`${lessonTypeColor[lesson.type]} flex-shrink-0`} />}
                              <span className="text-xs text-slate-300 flex-1">{lesson.title}</span>
                              <span className="text-xs text-slate-600">{lesson.type}</span>
                            </button>
                          );
                        })}
                        {/* Module test */}
                        {modTest && (
                          <button
                            onClick={() => { setActiveTest(modTest); setActiveLesson(null); setTestResult(null); setAnswers({}); }}
                            className={`w-full flex items-center gap-2 p-2.5 text-left hover:bg-slate-700/30 transition-all ${activeTest?._id === modTest._id ? 'bg-amber-500/10' : ''}`}
                          >
                            <FileText size={14} className="text-amber-400 flex-shrink-0" />
                            <span className="text-xs text-amber-300 flex-1">📝 Module Test</span>
                          </button>
                        )}
                        {/* Mark module done */}
                        {!isModuleDone(mod._id) && (
                          <button
                            onClick={() => handleMarkModule(mod._id)}
                            className="w-full p-2 text-xs text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/5 transition-all"
                          >
                            ✓ Mark Module Complete
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Final Test */}
            {finalTest && (
              <button
                onClick={() => { setActiveTest(finalTest); setActiveLesson(null); setTestResult(null); setAnswers({}); }}
                className={`w-full mt-3 p-3 rounded-lg border text-sm font-semibold flex items-center gap-2 transition-all ${finalTestPassed ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/10' : 'border-amber-500/30 text-amber-400 bg-amber-500/10 hover:bg-amber-500/20'}`}
              >
                📝 {finalTestPassed ? '✅ Final Test Passed' : 'Final Test'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Certificate Request Modal */}
      {showCertModal && (
        <Modal title="Request Certificate" onClose={() => setShowCertModal(false)}>
          <div className="text-center py-4">
            <div className="text-5xl mb-4">🏆</div>
            <h3 className="font-bold text-white mb-2">Congratulations!</h3>
            <p className="text-slate-400 text-sm mb-6">You've completed <strong className="text-white">{course.title}</strong>. Request your certificate now — your mentor will review and approve it.</p>
            <div className="flex gap-3">
              <button onClick={() => setShowCertModal(false)} className="btn-secondary flex-1">Cancel</button>
              <button onClick={handleCertRequest} className="btn-amber flex-1">Send Request</button>
            </div>
          </div>
        </Modal>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <Modal title="Report Content" onClose={() => setShowReportModal(false)}>
          <form onSubmit={handleReport} className="space-y-4">
            <p className="text-sm text-slate-400">Report inappropriate or inaccurate content to the admin.</p>
            <textarea
              className="input-field resize-none"
              rows={4}
              placeholder="Describe the issue..."
              value={reportMsg}
              onChange={(e) => setReportMsg(e.target.value)}
              required
            />
            <div className="flex gap-3">
              <button type="button" onClick={() => setShowReportModal(false)} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" className="btn-danger flex-1">Submit Report</button>
            </div>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  );
};

export default CourseLearning;
