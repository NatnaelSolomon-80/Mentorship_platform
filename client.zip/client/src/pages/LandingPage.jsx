import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  BookOpen, Users, Award, Shield, MessageCircle, BarChart3,
  ChevronRight, Star, ArrowRight, CheckCircle, Play, FileText,
  Briefcase, Lock, Zap, Globe, TrendingUp, Eye, Layers,
  GraduationCap, UserCheck, ClipboardCheck, BadgeCheck
} from 'lucide-react';

/* ─────────────────────── Animated Counter ─────────────────────── */
const Counter = ({ end, suffix = '', duration = 2000 }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = end / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= end) { setCount(end); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [end, duration]);
  return <>{count}{suffix}</>;
};

/* ─────────────────────── Navbar ─────────────────────── */
const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-slate-900/95 backdrop-blur-lg border-b border-white/5 shadow-xl' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center text-lg shadow-lg shadow-emerald-500/20">🌉</div>
          <div>
            <span className="font-bold text-white text-sm leading-tight block">Skill Bridge</span>
            <span className="text-[10px] text-slate-500 leading-tight block">Ethiopia</span>
          </div>
        </Link>
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-sm text-slate-400 hover:text-white transition-colors">Features</a>
          <a href="#how-it-works" className="text-sm text-slate-400 hover:text-white transition-colors">How It Works</a>
          <a href="#roles" className="text-sm text-slate-400 hover:text-white transition-colors">Roles</a>
          <a href="#certificates" className="text-sm text-slate-400 hover:text-white transition-colors">Certificates</a>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/login" className="text-sm text-slate-300 hover:text-white transition-colors font-medium px-4 py-2">Sign In</Link>
          <Link to="/register" className="btn-primary text-sm py-2 px-5 flex items-center gap-1.5">Get Started <ArrowRight size={14} /></Link>
        </div>
      </div>
    </nav>
  );
};

/* ─────────────────────── Hero Section ─────────────────────── */
const Hero = () => (
  <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
    {/* Background effects */}
    <div className="absolute inset-0 pointer-events-none">
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full bg-emerald-500/8 blur-[100px]" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-amber-500/6 blur-[80px]" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-blue-500/3 blur-[120px]" />
      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.3) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    </div>

    <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center relative z-10">
      {/* Left – Copy */}
      <div>
        <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-1.5 mb-6">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-medium text-emerald-400">Ethiopia's #1 Mentor-Guided LMS</span>
        </div>

        <h1 className="text-5xl lg:text-6xl font-black text-white leading-[1.1] mb-6">
          Learn with{' '}
          <span className="relative">
            <span className="gradient-text">Real Mentors</span>
            <svg className="absolute -bottom-2 left-0 w-full h-3 text-emerald-500/30" viewBox="0 0 200 8"><path d="M0 5 Q50 0 100 5 T200 5" fill="none" stroke="currentColor" strokeWidth="3" /></svg>
          </span>
          <br />
          Not Just Videos
        </h1>

        <p className="text-lg text-slate-400 leading-relaxed mb-8 max-w-lg">
          Skill Bridge connects students with approved mentors for guided learning, verified certificates, 
          and real skills that employers trust. No solo learning — real mentorship.
        </p>

        <div className="flex flex-wrap items-center gap-4 mb-10">
          <Link to="/register" className="btn-primary py-3.5 px-7 text-base flex items-center gap-2 shadow-lg shadow-emerald-500/25">
            <GraduationCap size={20} /> Start Learning Free
          </Link>
          <a href="#how-it-works" className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors font-medium group">
            <div className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center group-hover:border-emerald-500/50 group-hover:bg-emerald-500/10 transition-all">
              <Play size={14} className="ml-0.5" />
            </div>
            See How It Works
          </a>
        </div>

        {/* Trust indicators */}
        <div className="flex items-center gap-6 text-sm text-slate-500">
          <div className="flex items-center gap-1.5"><CheckCircle size={14} className="text-emerald-500" /> Free to join</div>
          <div className="flex items-center gap-1.5"><CheckCircle size={14} className="text-emerald-500" /> Verified Mentors</div>
          <div className="flex items-center gap-1.5"><CheckCircle size={14} className="text-emerald-500" /> Real Certificates</div>
        </div>
      </div>

      {/* Right – Interactive Dashboard Preview */}
      <div className="relative hidden lg:block">
        <div className="absolute -inset-4 bg-gradient-to-r from-emerald-500/10 to-amber-500/10 rounded-3xl blur-xl" />
        <div className="relative bg-slate-900/80 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl">
          {/* Fake top bar */}
          <div className="flex items-center gap-2 mb-5">
            <div className="w-3 h-3 rounded-full bg-red-500/60" />
            <div className="w-3 h-3 rounded-full bg-amber-500/60" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/60" />
            <span className="text-[10px] text-slate-600 ml-3">skillbridge.et/student/dashboard</span>
          </div>
          {/* Stats row */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            {[
              { label: 'Courses', value: '12', icon: BookOpen, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
              { label: 'Certificates', value: '5', icon: Award, color: 'text-amber-400', bg: 'bg-amber-500/10' },
              { label: 'Badges', value: '8', icon: Star, color: 'text-blue-400', bg: 'bg-blue-500/10' },
            ].map((s) => (
              <div key={s.label} className="bg-slate-800/60 border border-white/5 rounded-xl p-3">
                <div className={`w-7 h-7 rounded-lg ${s.bg} flex items-center justify-center mb-2`}><s.icon size={14} className={s.color} /></div>
                <p className="text-lg font-bold text-white">{s.value}</p>
                <p className="text-[10px] text-slate-500">{s.label}</p>
              </div>
            ))}
          </div>
          {/* Course cards */}
          <div className="space-y-2.5">
            {[
              { title: 'Advanced React & Next.js', mentor: 'Abebe K.', progress: 78, color: 'from-blue-500 to-cyan-500' },
              { title: 'Mobile App with Flutter', mentor: 'Sara M.', progress: 45, color: 'from-purple-500 to-pink-500' },
              { title: 'Python for Data Science', mentor: 'Daniel T.', progress: 92, color: 'from-emerald-500 to-teal-500' },
            ].map((c) => (
              <div key={c.title} className="bg-slate-800/40 border border-white/5 rounded-lg p-3 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${c.color} opacity-80 flex items-center justify-center flex-shrink-0`}>
                  <BookOpen size={16} className="text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-white truncate">{c.title}</p>
                  <p className="text-[10px] text-slate-500">Mentor: {c.mentor}</p>
                  <div className="mt-1 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full bg-gradient-to-r ${c.color}`} style={{ width: `${c.progress}%` }} />
                  </div>
                </div>
                <span className="text-xs font-bold text-slate-400">{c.progress}%</span>
              </div>
            ))}
          </div>
          {/* Notification toast */}
          <div className="absolute -right-4 top-20 bg-slate-800 border border-emerald-500/30 rounded-xl p-3 shadow-lg shadow-emerald-500/10 max-w-[200px] animate-bounce" style={{ animationDuration: '3s' }}>
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle size={14} className="text-emerald-400" />
              <span className="text-[10px] font-bold text-emerald-400">Mentor Accepted!</span>
            </div>
            <p className="text-[10px] text-slate-400">Your request to join "React" was accepted by Abebe K.</p>
          </div>
        </div>
      </div>
    </div>

    {/* Scroll indicator */}
    <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-600">
      <span className="text-xs">Scroll to explore</span>
      <div className="w-5 h-8 rounded-full border border-slate-600 flex items-start justify-center pt-1.5">
        <div className="w-1 h-2 rounded-full bg-emerald-500 animate-bounce" />
      </div>
    </div>
  </section>
);

/* ─────────────────────── Stats Bar ─────────────────────── */
const StatsBar = () => (
  <section className="relative py-12 border-y border-white/5" style={{ background: 'linear-gradient(180deg, rgba(5,150,105,0.03) 0%, transparent 100%)' }}>
    <div className="max-w-6xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
      {[
        { value: 500, suffix: '+', label: 'Active Learners', icon: Users },
        { value: 50, suffix: '+', label: 'Expert Mentors', icon: GraduationCap },
        { value: 120, suffix: '+', label: 'Courses Available', icon: BookOpen },
        { value: 300, suffix: '+', label: 'Certificates Issued', icon: Award },
      ].map((s) => (
        <div key={s.label}>
          <s.icon size={24} className="text-emerald-500 mx-auto mb-2 opacity-60" />
          <p className="text-3xl font-black text-white mb-1"><Counter end={s.value} suffix={s.suffix} /></p>
          <p className="text-sm text-slate-500">{s.label}</p>
        </div>
      ))}
    </div>
  </section>
);

/* ─────────────────────── Features Grid ─────────────────────── */
const features = [
  { icon: Users, title: 'Mentor-Guided Learning', desc: 'Students can only access course content after being accepted by a mentor. No solo learning.', color: 'from-emerald-500 to-teal-500' },
  { icon: Shield, title: 'Role-Based Access', desc: 'Four distinct roles — Student, Mentor, Employer, Admin — each with dedicated dashboards and permissions.', color: 'from-blue-500 to-cyan-500' },
  { icon: ClipboardCheck, title: 'Approval Workflow', desc: 'Mentors and courses require admin approval before going live. Quality control at every step.', color: 'from-amber-500 to-orange-500' },
  { icon: Award, title: 'Verified Certificates', desc: "Students earn printable certificates upon course completion, approved by their mentor.", color: 'from-purple-500 to-pink-500' },
  { icon: BadgeCheck, title: 'Achievement Badges', desc: 'Auto-assigned badges when certificates are issued. Gamified progress and recognition.', color: 'from-rose-500 to-red-500' },
  { icon: MessageCircle, title: 'Built-in Messaging', desc: 'Real-time chat between students and mentors. Ask questions, get guidance, stay connected.', color: 'from-indigo-500 to-blue-500' },
  { icon: BarChart3, title: 'Progress Tracking', desc: 'Detailed progress: lesson completion, module tracking, test scores — all in one view.', color: 'from-teal-500 to-green-500' },
  { icon: Briefcase, title: 'Employer Portal', desc: 'Employers browse a directory of certified students with verified skills and achievements.', color: 'from-slate-400 to-slate-600' },
  { icon: FileText, title: 'Content Reporting', desc: 'Students can flag inappropriate content. Admin reviews reports and takes action.', color: 'from-yellow-500 to-amber-500' },
];

const Features = () => (
  <section id="features" className="py-24 relative">
    <div className="absolute inset-0 pointer-events-none">
      <div className="absolute top-0 right-1/4 w-[400px] h-[400px] rounded-full bg-emerald-500/5 blur-[100px]" />
    </div>
    <div className="max-w-7xl mx-auto px-6 relative z-10">
      <div className="text-center mb-16">
        <span className="text-emerald-400 text-sm font-semibold uppercase tracking-wider">Platform Features</span>
        <h2 className="text-4xl font-black text-white mt-3 mb-4">Everything You Need to <span className="gradient-text">Learn & Grow</span></h2>
        <p className="text-slate-400 max-w-xl mx-auto">A comprehensive learning management system built for Ethiopian learners, mentors, and employers.</p>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
        {features.map((f, i) => (
          <div key={i} className="group glass p-6 hover:border-emerald-500/30 transition-all duration-300 hover:-translate-y-1">
            <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-4 opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all shadow-lg`}>
              <f.icon size={20} className="text-white" />
            </div>
            <h3 className="font-bold text-white text-base mb-2">{f.title}</h3>
            <p className="text-sm text-slate-400 leading-relaxed">{f.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

/* ─────────────────────── How It Works ─────────────────────── */
const steps = [
  { num: '01', title: 'Register & Choose Your Role', desc: 'Sign up as a Student, Mentor, or Employer. Students are auto-approved; Mentors & Employers await admin verification.', icon: UserCheck, color: 'from-emerald-500 to-teal-600' },
  { num: '02', title: 'Browse & Request a Mentor', desc: 'Students browse approved courses and send enrollment requests to mentors with a personal message.', icon: BookOpen, color: 'from-blue-500 to-indigo-600' },
  { num: '03', title: 'Mentor Accepts & Unlocks Content', desc: "Once a mentor accepts, the student gets full access to modules, lessons, videos, PDFs and notes.", icon: Lock, color: 'from-amber-500 to-orange-600' },
  { num: '04', title: 'Learn, Test & Track Progress', desc: "Complete lessons, mark modules done, take module and final tests. Track your progress in real-time.", icon: TrendingUp, color: 'from-purple-500 to-pink-600' },
  { num: '05', title: 'Earn Certificate & Badge', desc: 'Pass the final test (≥70%), request a certificate, mentor approves it, and you earn a badge automatically!', icon: Award, color: 'from-rose-500 to-red-600' },
];

const HowItWorks = () => (
  <section id="how-it-works" className="py-24 relative" style={{ background: 'linear-gradient(180deg, rgba(5,150,105,0.02) 0%, rgba(15,23,42,1) 50%, rgba(245,158,11,0.02) 100%)' }}>
    <div className="max-w-6xl mx-auto px-6">
      <div className="text-center mb-16">
        <span className="text-amber-400 text-sm font-semibold uppercase tracking-wider">The Journey</span>
        <h2 className="text-4xl font-black text-white mt-3 mb-4">How <span className="gradient-text">Skill Bridge</span> Works</h2>
        <p className="text-slate-400 max-w-xl mx-auto">From registration to certification — a mentor-guided path every step of the way.</p>
      </div>

      <div className="relative">
        {/* Connecting line */}
        <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-emerald-500/40 via-amber-500/40 to-rose-500/40 hidden md:block" />

        <div className="space-y-8">
          {steps.map((step, i) => (
            <div key={i} className="relative flex gap-6 items-start group">
              {/* Step number circle */}
              <div className={`relative z-10 w-16 h-16 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center flex-shrink-0 shadow-lg group-hover:scale-110 transition-transform`}>
                <step.icon size={24} className="text-white" />
              </div>

              {/* Content */}
              <div className="glass p-6 flex-1 group-hover:border-emerald-500/20 transition-all">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full">Step {step.num}</span>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{step.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

/* ─────────────────────── Roles Section ─────────────────────── */
const roleCards = [
  {
    role: 'Student', emoji: '🎓', color: 'from-emerald-500 to-teal-600', borderColor: 'border-emerald-500/20 hover:border-emerald-500/40',
    features: ['Browse & enroll in courses', 'Learn with video, PDFs & notes', 'Take module & final tests', 'Chat with your mentor', 'Earn certificates & badges', 'Track your progress'],
  },
  {
    role: 'Mentor', emoji: '👨‍🏫', color: 'from-blue-500 to-indigo-600', borderColor: 'border-blue-500/20 hover:border-blue-500/40',
    features: ['Create courses with modules', 'Accept or reject students', 'Add videos, notes & PDFs', 'Create tests & quiz questions', 'Approve certificates', 'Chat with your students'],
  },
  {
    role: 'Admin', emoji: '🛡️', color: 'from-amber-500 to-orange-600', borderColor: 'border-amber-500/20 hover:border-amber-500/40',
    features: ['Approve mentors & employers', 'Approve or reject courses', 'Manage all platform users', 'Review content reports', 'Create & manage badges', 'Full platform control'],
  },
  {
    role: 'Employer', emoji: '💼', color: 'from-purple-500 to-pink-600', borderColor: 'border-purple-500/20 hover:border-purple-500/40',
    features: ['Browse certified student pool', 'View verified certificates', 'See student skills & badges', 'Discover qualified talent', 'Filter by course completion', 'Trusted verification'],
  },
];

const Roles = () => (
  <section id="roles" className="py-24">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <span className="text-blue-400 text-sm font-semibold uppercase tracking-wider">For Everyone</span>
        <h2 className="text-4xl font-black text-white mt-3 mb-4">Four Roles, One <span className="gradient-text">Powerful Platform</span></h2>
        <p className="text-slate-400 max-w-xl mx-auto">Each role gets a dedicated dashboard with tailored features and permissions.</p>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
        {roleCards.map((r) => (
          <div key={r.role} className={`glass ${r.borderColor} transition-all duration-300 hover:-translate-y-2 overflow-hidden`}>
            {/* Header */}
            <div className={`bg-gradient-to-br ${r.color} p-5 text-center`}>
              <div className="text-4xl mb-2">{r.emoji}</div>
              <h3 className="text-lg font-bold text-white">{r.role}</h3>
            </div>
            {/* Features */}
            <div className="p-5">
              <ul className="space-y-2.5">
                {r.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-400">
                    <CheckCircle size={14} className="text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

/* ─────────────────────── Certificate Showcase ─────────────────────── */
const CertificateShowcase = () => (
  <section id="certificates" className="py-24 relative overflow-hidden">
    <div className="absolute inset-0 pointer-events-none">
      <div className="absolute bottom-0 left-1/3 w-[500px] h-[500px] rounded-full bg-amber-500/5 blur-[100px]" />
    </div>
    <div className="max-w-7xl mx-auto px-6 relative z-10">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        {/* Left — Info */}
        <div>
          <span className="text-amber-400 text-sm font-semibold uppercase tracking-wider">Achievements</span>
          <h2 className="text-4xl font-black text-white mt-3 mb-6">Earn <span className="gradient-text">Verified Certificates</span> & Badges</h2>
          <p className="text-slate-400 leading-relaxed mb-8">
            Every certificate is mentor-approved, printable, and verifiable. Employers can view your certificates
            directly on the platform. Badges are auto-awarded to gamify your learning journey.
          </p>
          <div className="space-y-4">
            {[
              { icon: CheckCircle, text: 'Complete all course modules' },
              { icon: FileText, text: 'Pass the final test with ≥70% score' },
              { icon: UserCheck, text: 'Request certificate — mentor approves' },
              { icon: BadgeCheck, text: 'Badge is automatically assigned' },
              { icon: Eye, text: 'Employers can view and verify' },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 group">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center group-hover:bg-amber-500/20 transition-colors">
                  <item.icon size={16} className="text-amber-400" />
                </div>
                <span className="text-sm text-slate-300">{item.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right — Certificate Visual */}
        <div className="relative">
          <div className="absolute -inset-4 bg-gradient-to-br from-amber-500/10 to-emerald-500/10 rounded-3xl blur-xl" />
          <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 border border-amber-500/20 rounded-2xl p-8 text-center shadow-2xl">
            {/* Certificate mockup */}
            <div className="border-2 border-amber-500/30 rounded-xl p-8 bg-slate-900/80 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-500 text-slate-900 text-xs font-bold px-4 py-1 rounded-full">CERTIFICATE</div>
              <div className="text-5xl mb-4">🏆</div>
              <p className="text-xs text-amber-400 uppercase tracking-widest mb-2">Certificate of Completion</p>
              <h3 className="text-xl font-bold text-white mb-1">Advanced React Development</h3>
              <p className="text-slate-400 text-sm mb-4">This is to certify that</p>
              <p className="text-lg font-bold gradient-text mb-1">Dawit Haile</p>
              <p className="text-slate-500 text-xs mb-4">has successfully completed the course under the guidance of <strong className="text-slate-300">Abebe Kebede</strong></p>
              <div className="flex items-center justify-center gap-6 mt-4">
                <div className="text-center">
                  <div className="w-16 border-t border-slate-600 mb-1" />
                  <p className="text-[10px] text-slate-600">Mentor Signature</p>
                </div>
                <div className="text-center">
                  <div className="w-16 border-t border-slate-600 mb-1" />
                  <p className="text-[10px] text-slate-600">Date Issued</p>
                </div>
              </div>
            </div>
            {/* Badge cards floating */}
            <div className="flex justify-center gap-3 mt-6">
              {['🏅', '⭐', '🎯', '💎'].map((b, i) => (
                <div key={i} className="w-12 h-12 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center text-xl hover:scale-110 hover:border-amber-500/30 transition-all cursor-default" style={{ animationDelay: `${i * 0.1}s` }}>
                  {b}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

/* ─────────────────────── Tech Stack ─────────────────────── */
const TechStack = () => (
  <section className="py-16 border-y border-white/5">
    <div className="max-w-5xl mx-auto px-6 text-center">
      <p className="text-sm text-slate-500 uppercase tracking-wider mb-6">Built with Modern Technology</p>
      <div className="flex flex-wrap items-center justify-center gap-8">
        {[
          { name: 'React', color: 'text-cyan-400' },
          { name: 'Node.js', color: 'text-green-400' },
          { name: 'Express', color: 'text-slate-300' },
          { name: 'MongoDB', color: 'text-emerald-400' },
          { name: 'Tailwind CSS', color: 'text-sky-400' },
          { name: 'JWT Auth', color: 'text-amber-400' },
          { name: 'Vite', color: 'text-purple-400' },
        ].map((t) => (
          <div key={t.name} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 border border-white/5 hover:border-white/15 transition-colors">
            <div className={`w-2 h-2 rounded-full ${t.color.replace('text-', 'bg-')}`} />
            <span className={`text-sm font-medium ${t.color}`}>{t.name}</span>
          </div>
        ))}
      </div>
    </div>
  </section>
);

/* ─────────────────────── CTA Section ─────────────────────── */
const CTA = () => (
  <section className="py-24">
    <div className="max-w-4xl mx-auto px-6">
      <div className="relative overflow-hidden rounded-3xl">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-teal-600" />
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.3) 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
        <div className="relative px-8 py-16 md:px-16 text-center">
          <div className="text-5xl mb-6">🌉</div>
          <h2 className="text-3xl md:text-4xl font-black text-white mb-4">
            Ready to Bridge the Gap?
          </h2>
          <p className="text-emerald-100/80 max-w-lg mx-auto mb-8">
            Join hundreds of Ethiopian learners already building real skills with verified mentors. Your journey starts today.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link to="/register" className="bg-white text-emerald-700 px-8 py-3.5 rounded-xl font-bold hover:bg-emerald-50 transition-colors shadow-lg flex items-center gap-2">
              Create Free Account <ArrowRight size={16} />
            </Link>
            <Link to="/login" className="border-2 border-white/30 text-white px-8 py-3.5 rounded-xl font-bold hover:bg-white/10 transition-colors flex items-center gap-2">
              Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  </section>
);

/* ─────────────────────── Footer ─────────────────────── */
const Footer = () => (
  <footer className="border-t border-white/5 py-12 text-center">
    <div className="max-w-6xl mx-auto px-6">
      <div className="flex items-center justify-center gap-2.5 mb-4">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center text-base">🌉</div>
        <span className="font-bold text-white">Skill Bridge Ethiopia</span>
      </div>
      <p className="text-sm text-slate-500 mb-6 max-w-md mx-auto">
        A mentor-guided learning management system built for Ethiopian learners, educators, and employers.
      </p>
      <div className="flex items-center justify-center gap-6 text-sm text-slate-600">
        <Link to="/login" className="hover:text-emerald-400 transition-colors">Sign In</Link>
        <Link to="/register" className="hover:text-emerald-400 transition-colors">Register</Link>
        <a href="#features" className="hover:text-emerald-400 transition-colors">Features</a>
        <a href="#how-it-works" className="hover:text-emerald-400 transition-colors">How It Works</a>
      </div>
      <div className="mt-8 pt-6 border-t border-white/5">
        <p className="text-xs text-slate-600">© 2026 Skill Bridge Ethiopia. Final Year Project — Built with ❤️</p>
      </div>
    </div>
  </footer>
);

/* ─────────────────────── Main Landing Page ─────────────────────── */
const LandingPage = () => (
  <div className="min-h-screen bg-slate-900">
    <Navbar />
    <Hero />
    <StatsBar />
    <Features />
    <HowItWorks />
    <Roles />
    <CertificateShowcase />
    <TechStack />
    <CTA />
    <Footer />
  </div>
);

export default LandingPage;
