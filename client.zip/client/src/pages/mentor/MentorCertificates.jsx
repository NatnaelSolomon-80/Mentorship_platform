import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import { apiGetCertRequests, apiRespondCertificate } from '../../api';
import toast from 'react-hot-toast';
import { Award, Check, X, ExternalLink } from 'lucide-react';

const MentorCertificates = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [responding, setResponding] = useState(null);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    try {
      const res = await apiGetCertRequests();
      setRequests(res.data.data || []);
    } catch { toast.error('Failed to load'); }
    finally { setLoading(false); }
  };

  const handleRespond = async (id, status) => {
    setResponding(id + status);
    try {
      await apiRespondCertificate(id, { status });
      toast.success(`Certificate ${status}!`);
      await load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setResponding(null); }
  };

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="Certificate Requests" subtitle="Review and approve student certificate requests" />

      {requests.length === 0 ? (
        <div className="glass p-12 text-center">
          <Award size={36} className="text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">No certificate requests yet</p>
        </div>
      ) : (
        <div className="space-y-4">
          {requests.map((req) => (
            <div key={req._id} className="glass p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center flex-shrink-0">
                <Award size={24} className="text-amber-400" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-white">{req.studentId?.name}</h3>
                <p className="text-sm text-slate-400">{req.courseId?.title}</p>
                <p className="text-xs text-slate-500 mt-1">Requested: {new Date(req.createdAt).toLocaleDateString()}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                {req.status === 'pending' ? (
                  <>
                    <button onClick={() => handleRespond(req._id, 'approved')} disabled={!!responding} className="btn-primary px-3 py-2 flex items-center gap-1 text-xs">
                      <Check size={14} /> Approve
                    </button>
                    <button onClick={() => handleRespond(req._id, 'rejected')} disabled={!!responding} className="btn-danger px-3 py-2 flex items-center gap-1 text-xs">
                      <X size={14} /> Reject
                    </button>
                  </>
                ) : (
                  <span className={`badge ${req.status === 'approved' ? 'badge-green' : 'badge-red'}`}>
                    {req.status}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
};

export default MentorCertificates;
