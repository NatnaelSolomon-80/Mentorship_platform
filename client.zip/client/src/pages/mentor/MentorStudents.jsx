import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import { apiGetEnrollmentRequests, apiRespondToRequest, apiGetMentorStudents, apiGetStudentsProgress } from '../../api';
import toast from 'react-hot-toast';
import { Check, X, Users, BookOpen } from 'lucide-react';

const MentorStudents = () => {
  const [requests, setRequests] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('requests');
  const [responding, setResponding] = useState(null);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    try {
      const [rRes, sRes] = await Promise.all([apiGetEnrollmentRequests(), apiGetMentorStudents()]);
      setRequests(rRes.data.data || []);
      setStudents(sRes.data.data || []);
    } catch { toast.error('Failed to load'); }
    finally { setLoading(false); }
  };

  const handleRespond = async (reqId, status) => {
    setResponding(reqId + status);
    try {
      await apiRespondToRequest(reqId, { status });
      toast.success(`Request ${status}!`);
      await loadAll();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setResponding(null); }
  };

  const pendingRequests = requests.filter((r) => r.status === 'pending');
  const allRequests = requests;

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader title="Students" subtitle="Manage enrollment requests and track your students" />

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-lg bg-slate-800/50 mb-6 w-fit">
        <button onClick={() => setTab('requests')} className={`px-4 py-2 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${tab === 'requests' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'}`}>
          Requests {pendingRequests.length > 0 && <span className="bg-amber-500 text-xs text-black font-bold px-1.5 py-0.5 rounded-full">{pendingRequests.length}</span>}
        </button>
        <button onClick={() => setTab('enrolled')} className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${tab === 'enrolled' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'}`}>
          Enrolled ({students.length})
        </button>
      </div>

      {tab === 'requests' && (
        <div>
          {allRequests.length === 0 ? (
            <div className="glass p-10 text-center">
              <Users size={32} className="text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">No enrollment requests yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {allRequests.map((req) => (
                <div key={req._id} className="glass p-4 flex items-center gap-4">
                  <div className="avatar">{req.studentId?.name?.[0]}</div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white">{req.studentId?.name}</p>
                    <p className="text-xs text-slate-400">{req.studentId?.email}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <BookOpen size={12} className="text-slate-500" />
                      <p className="text-xs text-slate-400">{req.courseId?.title}</p>
                    </div>
                    {req.message && <p className="text-xs text-slate-500 mt-1 italic">"{req.message}"</p>}
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {req.status === 'pending' ? (
                      <>
                        <button
                          onClick={() => handleRespond(req._id, 'accepted')}
                          disabled={responding === req._id + 'accepted'}
                          className="btn-primary px-3 py-2 flex items-center gap-1 text-xs"
                        >
                          <Check size={14} /> Accept
                        </button>
                        <button
                          onClick={() => handleRespond(req._id, 'rejected')}
                          disabled={responding === req._id + 'rejected'}
                          className="btn-danger px-3 py-2 flex items-center gap-1 text-xs"
                        >
                          <X size={14} /> Reject
                        </button>
                      </>
                    ) : (
                      <span className={`badge ${req.status === 'accepted' ? 'badge-green' : 'badge-red'}`}>
                        {req.status}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'enrolled' && (
        <div>
          {students.length === 0 ? (
            <div className="glass p-10 text-center">
              <Users size={32} className="text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">No students enrolled yet</p>
            </div>
          ) : (
            <div className="glass">
              <div className="table-container">
                <table>
                  <thead>
                    <tr>
                      <th>Student</th>
                      <th>Course</th>
                      <th>Enrolled Since</th>
                      <th>Skills</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((enrollment) => (
                      <tr key={enrollment._id}>
                        <td>
                          <div className="flex items-center gap-3">
                            <div className="avatar text-sm">{enrollment.studentId?.name?.[0]}</div>
                            <div>
                              <p className="font-medium text-white">{enrollment.studentId?.name}</p>
                              <p className="text-xs text-slate-500">{enrollment.studentId?.email}</p>
                            </div>
                          </div>
                        </td>
                        <td><p className="text-sm">{enrollment.courseId?.title}</p></td>
                        <td><p className="text-sm">{new Date(enrollment.createdAt).toLocaleDateString()}</p></td>
                        <td>
                          <div className="flex flex-wrap gap-1">
                            {(enrollment.studentId?.skills || []).slice(0, 3).map((s) => (
                              <span key={s} className="badge badge-slate text-xs">{s}</span>
                            ))}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </DashboardLayout>
  );
};

export default MentorStudents;
