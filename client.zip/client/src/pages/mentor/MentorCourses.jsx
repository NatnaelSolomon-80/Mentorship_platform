import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import PageHeader from '../../components/PageHeader';
import Modal from '../../components/Modal';
import { apiGetCourses, apiCreateCourse, apiUpdateCourse, apiDeleteCourse, apiGetModules, apiCreateModule, apiDeleteModule, apiGetLessons, apiCreateLesson, apiDeleteLesson, apiCreateTest } from '../../api';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';
import { Plus, Edit, Trash2, ChevronDown, ChevronRight, BookOpen, Play, FileText, Clock } from 'lucide-react';

const MentorCourses = () => {
  const { user } = useAuth();
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedCourse, setExpandedCourse] = useState(null);
  const [modules, setModules] = useState({});
  const [lessons, setLessons] = useState({});
  const [showCourseModal, setShowCourseModal] = useState(false);
  const [showModuleModal, setShowModuleModal] = useState(null); // courseId
  const [showLessonModal, setShowLessonModal] = useState(null); // moduleId
  const [courseForm, setCourseForm] = useState({ title: '', description: '', category: 'General', level: 'Beginner', thumbnail: '' });
  const [moduleForm, setModuleForm] = useState({ title: '', order: 0 });
  const [lessonForm, setLessonForm] = useState({ title: '', type: 'video', contentUrl: '', order: 0, duration: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadCourses();
  }, []);

  const loadCourses = async () => {
    try {
      const res = await apiGetCourses();
      setCourses(res.data.data || []);
    } catch { toast.error('Failed to load courses'); }
    finally { setLoading(false); }
  };

  const loadModules = async (courseId) => {
    const res = await apiGetModules(courseId);
    const mods = res.data.data || [];
    setModules((prev) => ({ ...prev, [courseId]: mods }));
    for (const mod of mods) await loadLessons(mod._id);
  };

  const loadLessons = async (moduleId) => {
    const res = await apiGetLessons(moduleId);
    setLessons((prev) => ({ ...prev, [moduleId]: res.data.data || [] }));
  };

  const toggleCourse = async (courseId) => {
    if (expandedCourse === courseId) { setExpandedCourse(null); return; }
    setExpandedCourse(courseId);
    if (!modules[courseId]) await loadModules(courseId);
  };

  const handleCreateCourse = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiCreateCourse(courseForm);
      toast.success('Course created! Pending admin approval.');
      setShowCourseModal(false);
      setCourseForm({ title: '', description: '', category: 'General', level: 'Beginner', thumbnail: '' });
      await loadCourses();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setSubmitting(false); }
  };

  const handleDeleteCourse = async (id) => {
    if (!confirm('Delete this course?')) return;
    try {
      await apiDeleteCourse(id);
      toast.success('Course deleted');
      await loadCourses();
    } catch { toast.error('Failed to delete'); }
  };

  const handleCreateModule = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiCreateModule({ ...moduleForm, courseId: showModuleModal });
      toast.success('Module added!');
      await loadModules(showModuleModal);
      setShowModuleModal(null);
      setModuleForm({ title: '', order: 0 });
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setSubmitting(false); }
  };

  const handleDeleteModule = async (moduleId, courseId) => {
    if (!confirm('Delete this module?')) return;
    try {
      await apiDeleteModule(moduleId);
      await loadModules(courseId);
      toast.success('Module deleted');
    } catch { toast.error('Failed'); }
  };

  const handleCreateLesson = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiCreateLesson({ ...lessonForm, moduleId: showLessonModal });
      toast.success('Lesson added!');
      await loadLessons(showLessonModal);
      setShowLessonModal(null);
      setLessonForm({ title: '', type: 'video', contentUrl: '', order: 0, duration: '' });
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setSubmitting(false); }
  };

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader
        title="My Courses"
        subtitle="Create and manage your course content"
        action={<button onClick={() => setShowCourseModal(true)} className="btn-primary flex items-center gap-2"><Plus size={16} /> New Course</button>}
      />

      {courses.length === 0 ? (
        <div className="glass p-12 text-center">
          <div className="text-5xl mb-4">📚</div>
          <h3 className="font-bold text-white mb-2">No courses yet</h3>
          <p className="text-slate-400 text-sm mb-4">Create your first course to start teaching!</p>
          <button onClick={() => setShowCourseModal(true)} className="btn-primary">Create Course</button>
        </div>
      ) : (
        <div className="space-y-4">
          {courses.map((course) => (
            <div key={course._id} className="glass overflow-hidden">
              {/* Course Header */}
              <div className="p-5 flex items-center gap-4">
                <button onClick={() => toggleCourse(course._id)} className="flex items-center gap-3 flex-1 text-left">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                    <BookOpen size={18} className="text-emerald-400" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-white">{course.title}</h3>
                      <span className={`badge ${course.isApproved ? 'badge-green' : 'badge-amber'}`}>
                        {course.isApproved ? 'Approved' : 'Pending'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{course.category} • {course.level}</p>
                  </div>
                  {expandedCourse === course._id ? <ChevronDown size={18} className="text-slate-400" /> : <ChevronRight size={18} className="text-slate-400" />}
                </button>
                <button onClick={() => handleDeleteCourse(course._id)} className="text-slate-500 hover:text-red-400 transition-colors p-2">
                  <Trash2 size={16} />
                </button>
              </div>

              {/* Expanded — Modules */}
              {expandedCourse === course._id && (
                <div className="border-t border-white/5 bg-slate-900/30 p-5">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm font-semibold text-slate-300">Modules ({modules[course._id]?.length || 0})</p>
                    <button onClick={() => setShowModuleModal(course._id)} className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1">
                      <Plus size={12} /> Add Module
                    </button>
                  </div>

                  {(modules[course._id] || []).map((mod) => (
                    <div key={mod._id} className="mb-3 rounded-lg border border-white/5 overflow-hidden">
                      <div className="flex items-center gap-2 p-3 bg-slate-800/50">
                        <p className="text-sm font-medium text-white flex-1">{mod.title}</p>
                        <button onClick={() => setShowLessonModal(mod._id)} className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1">
                          <Plus size={12} /> Lesson
                        </button>
                        <button onClick={() => handleDeleteModule(mod._id, course._id)} className="text-slate-500 hover:text-red-400 ml-2">
                          <Trash2 size={14} />
                        </button>
                      </div>
                      <div className="divide-y divide-white/5">
                        {(lessons[mod._id] || []).map((lesson) => (
                          <div key={lesson._id} className="flex items-center gap-2 p-2.5 pl-5">
                            {lesson.type === 'video' ? <Play size={13} className="text-blue-400" /> : <FileText size={13} className="text-amber-400" />}
                            <span className="text-xs text-slate-300 flex-1">{lesson.title}</span>
                            <span className="text-xs text-slate-600">{lesson.type}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Create Course Modal */}
      {showCourseModal && (
        <Modal title="Create New Course" onClose={() => setShowCourseModal(false)}>
          <form onSubmit={handleCreateCourse} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Title</label>
              <input className="input-field" placeholder="Course title" value={courseForm.title} onChange={(e) => setCourseForm({ ...courseForm, title: e.target.value })} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Description</label>
              <textarea className="input-field resize-none" rows={3} placeholder="What will students learn?" value={courseForm.description} onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })} required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Category</label>
                <input className="input-field" placeholder="e.g. Programming" value={courseForm.category} onChange={(e) => setCourseForm({ ...courseForm, category: e.target.value })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Level</label>
                <select className="input-field" value={courseForm.level} onChange={(e) => setCourseForm({ ...courseForm, level: e.target.value })}>
                  <option>Beginner</option><option>Intermediate</option><option>Advanced</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Thumbnail URL (optional)</label>
              <input className="input-field" placeholder="https://..." value={courseForm.thumbnail} onChange={(e) => setCourseForm({ ...courseForm, thumbnail: e.target.value })} />
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => setShowCourseModal(false)} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" className="btn-primary flex-1" disabled={submitting}>{submitting ? 'Creating...' : 'Create Course'}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Add Module Modal */}
      {showModuleModal && (
        <Modal title="Add Module" onClose={() => setShowModuleModal(null)}>
          <form onSubmit={handleCreateModule} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Module Title</label>
              <input className="input-field" placeholder="e.g. Introduction to JavaScript" value={moduleForm.title} onChange={(e) => setModuleForm({ ...moduleForm, title: e.target.value })} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Order</label>
              <input type="number" className="input-field" value={moduleForm.order} onChange={(e) => setModuleForm({ ...moduleForm, order: parseInt(e.target.value) })} />
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => setShowModuleModal(null)} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" className="btn-primary flex-1" disabled={submitting}>{submitting ? 'Adding...' : 'Add Module'}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Add Lesson Modal */}
      {showLessonModal && (
        <Modal title="Add Lesson" onClose={() => setShowLessonModal(null)}>
          <form onSubmit={handleCreateLesson} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Lesson Title</label>
              <input className="input-field" placeholder="Lesson name" value={lessonForm.title} onChange={(e) => setLessonForm({ ...lessonForm, title: e.target.value })} required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Type</label>
                <select className="input-field" value={lessonForm.type} onChange={(e) => setLessonForm({ ...lessonForm, type: e.target.value })}>
                  <option value="video">Video</option><option value="note">Note</option><option value="pdf">PDF</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Duration</label>
                <input className="input-field" placeholder="e.g. 12 min" value={lessonForm.duration} onChange={(e) => setLessonForm({ ...lessonForm, duration: e.target.value })} />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Content URL</label>
              <input className="input-field" placeholder={lessonForm.type === 'video' ? 'YouTube URL' : 'Google Drive / URL'} value={lessonForm.contentUrl} onChange={(e) => setLessonForm({ ...lessonForm, contentUrl: e.target.value })} required />
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => setShowLessonModal(null)} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" className="btn-primary flex-1" disabled={submitting}>{submitting ? 'Adding...' : 'Add Lesson'}</button>
            </div>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  );
};

export default MentorCourses;
