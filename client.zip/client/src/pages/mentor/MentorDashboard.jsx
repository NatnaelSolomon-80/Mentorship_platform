import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import StatCard from '../../components/StatCard';
import PageHeader from '../../components/PageHeader';
import { useAuth } from '../../context/AuthContext';
import { apiGetCourses, apiGetMentorStudents, apiGetEnrollmentRequests, apiGetCertRequests } from '../../api';
import { BookOpen, Users, Award, Clock, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';

const MentorDashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({ courses: 0, students: 0, pendingRequests: 0, pendingCerts: 0 });
  const [recentRequests, setRecentRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [cRes, sRes, rRes, crRes] = await Promise.all([
          apiGetCourses(),
          apiGetMentorStudents(),
          apiGetEnrollmentRequests(),
          apiGetCertRequests(),
        ]);
        setStats({
          courses: cRes.data.data?.length || 0,
          students: sRes.data.data?.length || 0,
          pendingRequests: rRes.data.data?.filter((r) => r.status === 'pending').length || 0,
          pendingCerts: crRes.data.data?.filter((r) => r.status === 'pending').length || 0,
        });
        setRecentRequests(rRes.data.data?.filter((r) => r.status === 'pending').slice(0, 4) || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <DashboardLayout><div className="flex justify-center py-20"><div className="spinner" /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <PageHeader
        title={`Hello, ${user?.name?.split(' ')[0]}! 👨‍🏫`}
        subtitle="Manage your courses and guide your students"
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard icon={BookOpen} label="My Courses" value={stats.courses} color="text-emerald-400" />
        <StatCard icon={Users} label="Active Students" value={stats.students} color="text-blue-400" />
        <StatCard icon={Clock} label="Pending Requests" value={stats.pendingRequests} color="text-amber-400" />
        <StatCard icon={Award} label="Cert Approvals" value={stats.pendingCerts} color="text-purple-400" />
      </div>

      {/* Pending Enrollment Requests */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="glass p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white">Pending Enrollment Requests</h2>
            <Link to="/mentor/students" className="text-sm text-emerald-400 hover:text-emerald-300">View All →</Link>
          </div>
          {recentRequests.length === 0 ? (
            <p className="text-slate-400 text-sm text-center py-6">No pending requests</p>
          ) : (
            <div className="space-y-3">
              {recentRequests.map((req) => (
                <div key={req._id} className="glass-sm p-3 flex items-center gap-3">
                  <div className="avatar text-sm">{req.studentId?.name?.[0]}</div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white">{req.studentId?.name}</p>
                    <p className="text-xs text-slate-400">{req.courseId?.title}</p>
                  </div>
                  <span className="badge badge-amber text-xs">Pending</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Links */}
        <div className="glass p-6">
          <h2 className="text-lg font-bold text-white mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <Link to="/mentor/courses" className="flex items-center gap-3 p-3 glass-sm hover:border-emerald-500/30 transition-all">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center"><BookOpen size={16} className="text-emerald-400" /></div>
              <div><p className="text-sm font-semibold text-white">Create New Course</p><p className="text-xs text-slate-400">Add content for students</p></div>
            </Link>
            <Link to="/mentor/students" className="flex items-center gap-3 p-3 glass-sm hover:border-blue-500/30 transition-all">
              <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center"><Users size={16} className="text-blue-400" /></div>
              <div><p className="text-sm font-semibold text-white">Review Student Requests</p><p className="text-xs text-slate-400">Accept or reject enrollments</p></div>
            </Link>
            <Link to="/mentor/certificates" className="flex items-center gap-3 p-3 glass-sm hover:border-amber-500/30 transition-all">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center"><Award size={16} className="text-amber-400" /></div>
              <div><p className="text-sm font-semibold text-white">Approve Certificates</p><p className="text-xs text-slate-400">Review certificate requests</p></div>
            </Link>
            <Link to="/mentor/chat" className="flex items-center gap-3 p-3 glass-sm hover:border-purple-500/30 transition-all">
              <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center"><TrendingUp size={16} className="text-purple-400" /></div>
              <div><p className="text-sm font-semibold text-white">Chat with Students</p><p className="text-xs text-slate-400">Answer questions and guide</p></div>
            </Link>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default MentorDashboard;
