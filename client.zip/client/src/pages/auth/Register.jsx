import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRegister } from '../../api';
import toast from 'react-hot-toast';
import { UserPlus, Eye, EyeOff, CheckCircle } from 'lucide-react';

const roles = [
  { value: 'student', label: 'Student', desc: 'Learn from mentors', emoji: '🎓' },
  { value: 'mentor', label: 'Mentor', desc: 'Teach and guide learners', emoji: '👨‍🏫' },
  { value: 'employer', label: 'Employer', desc: 'Discover certified talent', emoji: '💼' },
];

const Register = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'student' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password.length < 6) return toast.error('Password must be at least 6 characters');
    setLoading(true);
    try {
      const { data } = await apiRegister(form);
      setSuccessMsg(data.message);
      setSuccess(true);
      toast.success(data.message);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: '#0f172a' }}>
        <div className="glass p-10 max-w-md w-full text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} className="text-emerald-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Registration Successful!</h2>
          <p className="text-slate-400 text-sm mb-6">{successMsg}</p>
          <button onClick={() => navigate('/login')} className="btn-primary w-full">
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 py-10" style={{ background: 'radial-gradient(ellipse at 20% 50%, rgba(5,150,105,0.08) 0%, transparent 60%), #0f172a' }}>
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-amber-500 text-3xl mb-4 shadow-lg shadow-emerald-500/20">
            🌉
          </div>
          <h1 className="text-3xl font-bold text-white mb-1">Join Skill Bridge</h1>
          <p className="text-slate-400 text-sm">Ethiopia's Premier Learning Platform</p>
        </div>

        <div className="glass p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Full Name</label>
              <input className="input-field" placeholder="Abebe Bekele" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Email Address</label>
              <input type="email" className="input-field" placeholder="you@example.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Password</label>
              <div className="relative">
                <input type={showPass ? 'text' : 'password'} className="input-field pr-11" placeholder="Min. 6 characters" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white">
                  {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Role Selector */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">I want to join as</label>
              <div className="grid grid-cols-3 gap-2">
                {roles.map((r) => (
                  <button
                    key={r.value}
                    type="button"
                    onClick={() => setForm({ ...form, role: r.value })}
                    className={`p-3 rounded-lg border text-center transition-all ${form.role === r.value ? 'border-emerald-500 bg-emerald-500/10' : 'border-white/10 bg-slate-800/50 hover:border-white/20'}`}
                  >
                    <div className="text-xl mb-1">{r.emoji}</div>
                    <p className="text-xs font-semibold text-white">{r.label}</p>
                    <p className="text-xs text-slate-500 mt-0.5 leading-tight">{r.desc}</p>
                  </button>
                ))}
              </div>
              {(form.role === 'mentor' || form.role === 'employer') && (
                <p className="text-xs text-amber-400 mt-2 flex items-center gap-1">
                  ⚠️ {form.role === 'mentor' ? 'Mentors' : 'Employers'} require admin approval before full access.
                </p>
              )}
            </div>

            <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2 py-3" disabled={loading}>
              {loading ? <div className="spinner w-5 h-5 border-2" /> : <><UserPlus size={18} /> Create Account</>}
            </button>
          </form>

          <p className="text-center text-sm text-slate-400 mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-emerald-400 font-semibold hover:text-emerald-300">Sign In</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;
