import { useEffect, useState } from 'react';
import DashboardLayout from '../../components/DashboardLayout';
import StatCard from '../../components/StatCard';
import PageHeader from '../../components/PageHeader';
import { apiGetCertifiedStudents } from '../../api';
import { Users, Award, Briefcase } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const EmployerDashboard = () => {
  const { user } = useAuth();
  const [certifiedCount, setCertifiedCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGetCertifiedStudents()
      .then((res) => setCertifiedCount(res.data.data?.length || 0))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <DashboardLayout>
      <PageHeader title={`Welcome, ${user?.name?.split(' ')[0]}! 💼`} subtitle="Discover certified talent from Skill Bridge Ethiopia" />

      {loading ? (
        <div className="flex justify-center py-20"><div className="spinner" /></div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <StatCard icon={Users} label="Certified Students" value={certifiedCount} color="text-emerald-400" />
            <StatCard icon={Award} label="Verified Skills" value="100%" color="text-amber-400" />
            <StatCard icon={Briefcase} label="Available Now" value={certifiedCount} color="text-blue-400" />
          </div>

          <div className="glass p-8 text-center">
            <div className="text-5xl mb-4">🏆</div>
            <h2 className="text-xl font-bold text-white mb-2">Talent Pool Ready</h2>
            <p className="text-slate-400 text-sm max-w-md mx-auto mb-6">
              Browse our directory of certified students who have completed mentor-guided courses with verified skills and achievements.
            </p>
            <Link to="/employer/students" className="btn-primary inline-flex items-center gap-2">
              <Users size={16} /> Browse Talent Pool
            </Link>
          </div>
        </>
      )}
    </DashboardLayout>
  );
};

export default EmployerDashboard;
