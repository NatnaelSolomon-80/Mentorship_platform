import { useAuth } from '../context/AuthContext';
import { useNavigate, NavLink } from 'react-router-dom';
import {
  LayoutDashboard, BookOpen, Users, MessageCircle, Award, Shield,
  FileText, LogOut, Settings, Bell, ChevronRight, Star, Briefcase
} from 'lucide-react';

const studentLinks = [
  { to: '/student/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/student/browse', icon: BookOpen, label: 'Browse Courses' },
  { to: '/student/courses', icon: Star, label: 'My Courses' },
  { to: '/student/chat', icon: MessageCircle, label: 'Chat' },
  { to: '/student/certificates', icon: Award, label: 'Certificates' },
  { to: '/student/badges', icon: Shield, label: 'Badges' },
];

const mentorLinks = [
  { to: '/mentor/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/mentor/courses', icon: BookOpen, label: 'My Courses' },
  { to: '/mentor/students', icon: Users, label: 'Students' },
  { to: '/mentor/certificates', icon: Award, label: 'Certificates' },
  { to: '/mentor/chat', icon: MessageCircle, label: 'Chat' },
];

const adminLinks = [
  { to: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/admin/users', icon: Users, label: 'Users' },
  { to: '/admin/courses', icon: BookOpen, label: 'Courses' },
  { to: '/admin/reports', icon: FileText, label: 'Reports' },
  { to: '/admin/badges', icon: Award, label: 'Badges' },
];

const employerLinks = [
  { to: '/employer/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/employer/students', icon: Users, label: 'Talent Pool' },
];

const linksByRole = { student: studentLinks, mentor: mentorLinks, admin: adminLinks, employer: employerLinks };

const roleColors = {
  student: 'text-emerald-400',
  mentor: 'text-blue-400',
  admin: 'text-amber-400',
  employer: 'text-purple-400',
};

const roleIcons = { student: Star, mentor: BookOpen, admin: Shield, employer: Briefcase };

const Sidebar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const links = linksByRole[user?.role] || [];
  const RoleIcon = roleIcons[user?.role] || Star;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside className="sidebar flex flex-col">
      {/* Logo */}
      <div className="px-5 pb-6 mb-2 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center text-lg">
            🌉
          </div>
          <div>
            <p className="font-bold text-sm text-white leading-tight">Skill Bridge</p>
            <p className="text-xs text-slate-500">Ethiopia LMS</p>
          </div>
        </div>
      </div>

      {/* User info */}
      <div className="px-4 mb-4">
        <div className="glass-sm p-3 flex items-center gap-3">
          <div className="avatar text-sm">{user?.name?.[0]?.toUpperCase()}</div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white truncate">{user?.name}</p>
            <div className="flex items-center gap-1">
              <RoleIcon size={10} className={roleColors[user?.role]} />
              <p className={`text-xs capitalize ${roleColors[user?.role]}`}>{user?.role}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Nav links */}
      <nav className="flex-1 px-2">
        <p className="px-3 mb-2 text-xs font-semibold text-slate-600 uppercase tracking-wider">Menu</p>
        {links.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
          >
            <Icon size={18} />
            <span>{label}</span>
            <ChevronRight size={14} className="ml-auto opacity-0 group-hover:opacity-100" />
          </NavLink>
        ))}
      </nav>

      {/* Bottom actions */}
      <div className="px-2 mt-4 border-t border-white/5 pt-4">
        <button
          onClick={handleLogout}
          className="sidebar-link w-full text-red-400 hover:text-red-300 hover:bg-red-900/20"
        >
          <LogOut size={18} />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
