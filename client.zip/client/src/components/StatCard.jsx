const StatCard = ({ icon: Icon, label, value, color = 'text-emerald-400', trend }) => (
  <div className="stat-card">
    <div className="flex items-start justify-between mb-3">
      <div className={`w-10 h-10 rounded-lg bg-current/10 flex items-center justify-center ${color}`} style={{ background: 'rgba(5,150,105,0.1)' }}>
        <Icon size={20} className={color} />
      </div>
      {trend !== undefined && (
        <span className={`text-xs font-semibold ${trend >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
          {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}%
        </span>
      )}
    </div>
    <p className="text-2xl font-bold text-white mb-1">{value}</p>
    <p className="text-sm text-slate-500">{label}</p>
  </div>
);

export default StatCard;
